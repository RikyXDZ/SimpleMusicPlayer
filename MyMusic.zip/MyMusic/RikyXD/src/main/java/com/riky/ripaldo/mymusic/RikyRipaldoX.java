package com.riky.ripaldo.mymusic;

import android.Manifest;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PorterDuff;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.util.ArrayList;

public class RikyRipaldoX extends AppCompatActivity
{
    private String pos = "Music Berhenti";
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.riky_ripaldo_main);

        listView = findViewById(R.id.listview);
        image = findViewById(R.id.image);

        back = findViewById(R.id.back);
        play = findViewById(R.id.play);
        next = findViewById(R.id.forw);
        text = findViewById(R.id.text);

        startTime = findViewById(R.id.startTime);
        finalTime = findViewById(R.id.finalTime);
        seekbarOne = findViewById(R.id.seekbarOne);
        seekbarTwo = findViewById(R.id.seekbarTwo);

        RequestsPermissionAndroidSystemFromLinuxKernel();

        final ArrayList<File> Lagu = cariLagu(Environment.getExternalStorageDirectory());
        lagu = new String[Lagu.size()];
        for (int i=0;i < Lagu.size();i++)
        {
            lagu[i] = Lagu.get(i).getName().toString().replace(".mp3", "").replace(".wav", "");
        }    

        RikyAdapter RikyXD = new RikyAdapter();
        listView.setAdapter(RikyXD);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){        
                @Override
                public void onItemClick(AdapterView<?>  adapterView, View View, int position, long l)
                {
                    if (mp != null)
                    {
                        mp.stop();
                        mp.release();
                    }
                    Uri myMusic = Uri.parse(Lagu.get(position).toString());
                    String name = Lagu.get(position).getName();
                    mp = MediaPlayer.create(getApplicationContext(), myMusic);

                    String TimeUnitFinal = Time(mp.getDuration());
                    finalTime.setText(TimeUnitFinal);

                    final Handler hand = new Handler();
                    final int delay = 1000;

                    hand.postDelayed(new Runnable() {
                            @Override
                            public void run()
                            {
                                String Time = Time(mp.getCurrentPosition());
                                startTime.setText(Time);
                                hand.postDelayed(this, delay);
                            }
                        }, delay);

                    if (mp.isPlaying())
                    {
                        if (mp != null)
                        {
                            mp.stop();
                            mp.release();
                        }
                        else
                        {
                            mp.pause();
                            text.setText(pos);
                        }
                    }
                    else
                    {
                        mp.start();
                        text.setText(name.toString());
                        gantiLagu();
                    }         

                    Update = new Thread(){
                        @Override
                        public void run()
                        {
                            int fullTime = mp.getDuration();
                            int currentPos = 0;

                            while (currentPos < fullTime)
                            {
                                try
                                {
                                    sleep(500);
                                    currentPos = mp.getCurrentPosition();
                                    seekbarOne.setProgress(currentPos);
                                    seekbarTwo.setProgress(currentPos);
                                }
                                catch (InterruptedException | IllegalAccessError e)
                                {
                                    e.printStackTrace();
                                }
                            }
                        }
                    };

                    seekbarOne.setMax(mp.getDuration());
                    seekbarTwo.setMax(mp.getDuration());
                    Update.start();
                    seekbarOne.getProgressDrawable().setColorFilter(getResources().getColor(R.color.colorPrimary), PorterDuff.Mode.MULTIPLY);
                    seekbarOne.getThumb().setColorFilter(getResources().getColor(R.color.colorPrimary), PorterDuff.Mode.SRC_IN);
                    seekbarTwo.getProgressDrawable().setColorFilter(getResources().getColor(R.color.colorAccent), PorterDuff.Mode.MULTIPLY);
                    seekbarTwo.getThumb().setColorFilter(getResources().getColor(R.color.colorAccent), PorterDuff.Mode.SRC_IN);            
                }
            });       

        seekbarOne.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                @Override
                public void onProgressChanged(SeekBar seekbarOne, int i, boolean b)
                {
                }
                @Override
                public void onStartTrackingTouch(SeekBar seekbarOne)
                {           
                }
                @Override
                public void onStopTrackingTouch(SeekBar seekbarOne)
                {
                    mp.seekTo(seekbarOne.getProgress());
                    gantiLagu();
                }
            });

        seekbarTwo.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                @Override
                public void onProgressChanged(SeekBar seekbarTwo, int i, boolean b)
                {
                }
                @Override
                public void onStartTrackingTouch(SeekBar seekbarTwo)
                {           
                }
                @Override
                public void onStopTrackingTouch(SeekBar seekbarTwo)
                {
                    mp.seekTo(seekbarTwo.getProgress());
                    gantiLagu();
                }
            });

        play.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view)
                {
                    try
                    {
                        if (mp.isPlaying())
                        {
                            mp.pause();
                            play.setBackgroundResource(R.drawable.riky_ripaldo_play);
                            text.setText(pos);
                        }
                        else
                        {
                            mp.start();
                            play.setBackgroundResource(R.drawable.riky_ripaldo_pause);
                            String name = Lagu.get(position).getName();
                            text.setText(name.toString());
                            gantiLagu();
                        }
                    }
                    catch (Exception e)
                    {
                        Toast.makeText(getApplicationContext(), "Silahkan Pilih Lagu Terlebih Dahulu 🤣", Toast.LENGTH_SHORT).show();
                    }
                }
            });

        next.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view)
                {
                    try
                    {
                        mp.stop();
                        mp.release();

                        position = ((position + 1) % Lagu.size());
                        Uri music = Uri.parse(Lagu.get(position).toString());
                        String name = Lagu.get(position).getName();
                        mp = MediaPlayer.create(getApplicationContext(), music);

                        mp.start();
                        text.setText(name.toString());

                        try
                        {
                            Animasi(image);
                        }
                        catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                        gantiLagu();
                    }
                    catch (Exception e)
                    {
                        Toast.makeText(getApplicationContext(), "Silahkan Pilih Lagu Terlebih Dahulu 🤣", Toast.LENGTH_SHORT).show();
                    }
                }
            });

        back.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view)
                {
                    try
                    {
                        mp.stop();
                        mp.release();

                        position = ((position - 1) < 0) ?(Lagu.size() - 1): (position - 1);
                        Uri music = Uri.parse(Lagu.get(position).toString());
                        String name = Lagu.get(position).getName();
                        mp = MediaPlayer.create(getApplicationContext(), music);

                        mp.start();
                        text.setText(name.toString());

                        try
                        {
                            Animasi(image);
                        }
                        catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                        gantiLagu();
                    }
                    catch (Exception e)
                    {
                        Toast.makeText(getApplicationContext(), "Silahkan Pilih Lagu Terlebih Dahulu 🤣", Toast.LENGTH_SHORT).show();
                    }
                }
            });
    }

    public void gantiLagu()
    {
        mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){
                @Override
                public void onCompletion(MediaPlayer mp)
                {
                    next.performClick();
                }
            });
    }

    public void RequestsPermissionAndroidSystemFromLinuxKernel()
    {
        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
        {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, MODE_PRIVATE);
            Toast.makeText(getApplicationContext(), "Silahkan Mulai Ulang Aplikasi 😎", Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(getApplicationContext(), "Crated By Riky Ripaldo 😎", Toast.LENGTH_LONG).show();
        }
    }

    public ArrayList<File> cariLagu(File root)
    {
        ArrayList<File> arrayList = new ArrayList<>();
        File[] files = root.listFiles();

        for (File selfFile: files)
        {
            if (selfFile.isDirectory() && !selfFile.isHidden())
            {
                arrayList.addAll(cariLagu(selfFile));
            }
            else
            {
                if (selfFile.getName().endsWith(".mp3") || selfFile.getName().endsWith(".wav"))
                {
                    arrayList.add(selfFile);
                }
            }
        }
        return arrayList;
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        mp.release();
    }


    public void Animasi(View view)
    {
        ObjectAnimator animator = ObjectAnimator.ofFloat(image, "rotation", 0f, 360f);
        animator.setDuration(1000);
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(animator);
        animatorSet.start();
    }

    public String Time(int duration)
    {
        String time = "";
        int minutes = duration / 1000 / 60;
        int seconds = duration / 1000 % 60;

        time += minutes + ":";

        if (seconds < 10)
        {
            time += "0";
        }
        time += seconds;
        return time;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if (item.getItemId() == android.R.id.home)
        {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    public void Black(View view)
    {
        try
        {
            if (mp.isPlaying())
            {
                mp.seekTo(mp.getCurrentPosition() - 10000);
            }
            Toast.makeText(getApplicationContext(), "Mundur 5 detik 😝", Toast.LENGTH_SHORT).show();
        }
        catch (Exception e)
        {
            Toast.makeText(getApplicationContext(), "Silahkan Pilih Lagu Terlebih Dahulu 🤣", Toast.LENGTH_SHORT).show();         
        }
    }

    public void White(View view)
    {
        try
        {
            if (mp.isPlaying())
            {
                mp.seekTo(mp.getCurrentPosition() + 10000);
            }
            Toast.makeText(getApplicationContext(), "Maju 5 detik 😝", Toast.LENGTH_SHORT).show();
        }
        catch (Exception e)
        {
            Toast.makeText(getApplicationContext(), "Silahkan Pilih Lagu Terlebih Dahulu 🤣", Toast.LENGTH_SHORT).show();         
        }
    }

    public void OpenMyWhatsapp(View view)
    {
        Toast.makeText(getApplicationContext(), "Membuka Whatsapp 😝", Toast.LENGTH_SHORT).show();
        Intent open = new Intent(Intent.ACTION_VIEW);
        open.setData(Uri.parse("https://api.whatsapp.com/send?phone=6285789116608&text=Assalamualaikum%20Warahmatulahi%20Wabarakathu%20"));
        startActivity(open);
    }

    // Inisialisasi Import
    private MediaPlayer mp;
    private Button back, play, next;   
    private ImageView image;
    private ListView listView;
    private String[] lagu;
    private int position;
    private Thread Update;
    private SeekBar seekbarOne, seekbarTwo;
    private TextView text, startTime, finalTime;

    class RikyAdapter extends BaseAdapter
    {
        @Override
        public int getCount()
        {
            return lagu.length;
        }

        @Override
        public Object getItem(int i)
        {
            return null;
        }

        @Override
        public long getItemId(int i)
        {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup)
        {
            view = getLayoutInflater().inflate(R.layout.riky_riplado_listview, null);
            TextView textsong = view.findViewById(R.id.textsound);
            textsong.setSelected(true);
            textsong.setText(lagu[i]);

            return view;
        }
    }
}
